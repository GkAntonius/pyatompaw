
from .namer import AtompawNamer
from .launcher import AtompawLauncher
from .inputfile import AtompawInput
from .plotter import AtompawPlotter

__all__ = ['AtompawMaster']

class AtompawMaster(AtompawNamer):
    """The head."""

    def __init__(self, rootname, *args, **kwargs):

        AtompawNamer.__init__(self, rootname, *args, **kwargs)

        self.launcher = AtompawLauncher(namer=self)
        self.plotter = AtompawPlotter(namer=self)

    def plot_wfn(self, pdf=True):
        Nproj = self.launcher.inputfile.nproj
        self.plotter.plot_wfn(Nproj, pdf=pdf)

    def plot_logderiv(self, pdf=False):
        Nl = self.launcher.inputfile.lmax
        self.plotter.plot_logderiv(Nl, pdf=pdf)

# =========================================================================== #
# Link various functions and properties

def set_launcher_function(cls, func_name):
    def f(self, *args, **kwargs):
        return getattr(self.launcher, func_name)(*args, **kwargs)
    f.__doc__ = getattr(AtompawLauncher, func_name).__doc__
    setattr(cls, func_name, f)

for function in AtompawLauncher._to_master_functions:
    set_launcher_function(AtompawMaster, function)


def set_input_function(cls, func_name):
    def f(self, *args, **kwargs):
        return getattr(self.launcher.inputfile, func_name)(*args, **kwargs)
    f.__doc__ = getattr(AtompawInput, func_name).__doc__
    setattr(cls, func_name, f)

for function in AtompawInput._to_master_functions:
    set_input_function(AtompawMaster, function)

def set_input_property(cls, prop_name):
    def getter(self):
        return getattr(self.launcher.inputfile, prop_name)
    def setter(self, val):
        return setattr(self.launcher.inputfile, prop_name, val)
    setattr(cls, prop_name, property(getter, setter))


for prop in AtompawInput._to_master_properties:
    set_input_property(AtompawMaster, prop)

